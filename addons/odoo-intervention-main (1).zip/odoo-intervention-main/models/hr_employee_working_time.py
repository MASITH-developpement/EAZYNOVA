# -*- coding: utf-8 -*-

# Module vide - À supprimer ou implémenter selon les besoins
