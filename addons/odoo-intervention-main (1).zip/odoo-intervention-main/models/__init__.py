# -*- coding: utf-8 -*-

from . import intervention
from . import intervention_quick_create
from . import materiel
from . import geocoding_cache
from . import res_partner
from . import res_config_settings
from . import sale_account_models
from . import res_users
from . import intervention_mail_config
