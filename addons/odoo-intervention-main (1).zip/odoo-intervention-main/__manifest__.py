# -*- coding: utf-8 -*-
{
    'name': "Interventions",
    'version': '1.0',
    'license': 'LGPL-3',
    'summary': "Gestion complète des interventions technique",
    'description': """
        Module de gestion des interventions technique de depannage
        
        **Fonctionnalités principales :**
        • Planification des interventions avec calendrier intégré
        • Gestion des techniciens et équipes
        • Suivi en temps réel des interventions
        • Géolocalisation et calcul de distance automatique
        • Photos avant/après intervention
        • Génération automatique de devis et factures
        • Rapports PDF d'intervention
        • Validation client avec signature
        • Interface mobile optimisée
        
        **Avantages :**
        • Interface intuitive et moderne
        • Automatisation des tâches répétitives
        • Suivi complet du cycle de vie des interventions
        • Intégration avec les modules Odoo standards
        • Rapports détaillés et analyses
    """,
    'author': "MASITH",
    'maintainer': "MASITH",
    'website': "https://www.masith.fr",
    'category': 'Services',
    'depends': [
        'base', 'hr', 'hr_contract', 'hr_holidays', 'hr_skills', 'mail', 'contacts', 'base_automation',
        'product', 'stock', 'calendar', 'hr_calendar', 'account', 'sale_management', 'crm', 'purchase', 'web', 'board'
    ],
    'data': [
        'security/intervention_security.xml',
        'security/intervention_rules.xml',
        'security/ir.model.access.csv',
        'views/res_config_settings_views.xml',
        'views/intervention_config_views.xml',
        'views/intervention_config_settings.xml',
        'data/sequences_data.xml',
        'data/mail_templates_data.xml',
        'data/automation_send_report.xml',
        'data/automation_incoming_mail.xml',
        'data/cron_cleanup_geocoding.xml',
        'views/intervention_actions.xml',
        'views/intervention_views.xml',
        'views/intervention_quick_create_views.xml',
        'views/intervention_menus.xml',
        'views/intervention_mail_config_views.xml',
        'views/settings_views.xml',
        'views/intervention_colors_template.xml',
        'report/intervention_reports.xml',
        'views/intervention_report_templates.xml',
        'wizard/intervention_validation_wizard_views.xml',
        'views/res_users_view.xml',
        'views/res_partner_latlong.xml',
        'security/intervention_user_access_rules.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'intervention/static/src/css/intervention_enhanced.css',
            'intervention/static/src/css/intervention_override.css',
        ],
    },
    'images': [
        'static/description/banner.png',
        'static/description/main_screenshot.png',
    ],
    'installable': True,
    'application': True,
    'live_test_url': 'https://www.masith.fr',
}
